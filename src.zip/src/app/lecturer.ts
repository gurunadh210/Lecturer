export interface Lecturer {     //this is a lecturer interface class
    id: number;                 //this is a datatypes  
    name: string;
    email: string;
    phonenumber: number;

}